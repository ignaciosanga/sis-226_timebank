-- ============================================
-- MIGRACIÓN DE ENCRIPTACIÓN - Base de Datos v0.31
-- Sistema de Intercambio de Habilidades
-- ============================================
-- Este archivo implementa encriptación para datos sensibles
-- utilizando la extensión pgcrypto de PostgreSQL
-- ============================================

-- ============================================
-- 1. HABILITAR EXTENSIÓN PGCrypto
-- ============================================
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ============================================
-- 2. CONFIGURACIÓN DE CLAVES DE ENCRIPTACIÓN
-- ============================================
-- NOTA DE SEGURIDAD IMPORTANTE:
-- En producción, las claves deben almacenarse en:
-- - Variables de entorno
-- - Vault (HashiCorp Vault)
-- - AWS Secrets Manager / Azure Key Vault
-- NUNCA en código o archivos de configuración

-- Clave maestra para encriptación (32 bytes para AES-256)
-- En producción: obtener desde variable de entorno
CREATE OR REPLACE FUNCTION get_encryption_key()
RETURNS bytea AS $$
BEGIN
  -- DESARROLLO: clave temporal (CAMBIAR EN PRODUCCIÓN)
  RETURN decode('a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2', 'hex');

  -- PRODUCCIÓN: usar variable de entorno
  -- RETURN decode(current_setting('app.encryption_key'), 'hex');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- 3. FUNCIONES DE ENCRIPTACIÓN/DESENCRIPTACIÓN
-- ============================================

-- Encriptar texto usando AES-256
CREATE OR REPLACE FUNCTION encrypt_text(plain_text text)
RETURNS bytea AS $$
BEGIN
  IF plain_text IS NULL THEN
    RETURN NULL;
  END IF;
  RETURN encrypt(
    plain_text::bytea,
    get_encryption_key(),
    'aes'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Desencriptar texto usando AES-256
CREATE OR REPLACE FUNCTION decrypt_text(encrypted_data bytea)
RETURNS text AS $$
BEGIN
  IF encrypted_data IS NULL THEN
    RETURN NULL;
  END IF;
  RETURN convert_from(
    decrypt(
      encrypted_data,
      get_encryption_key(),
      'aes'
    ),
    'UTF8'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- 4. COLUMNAS ENCRIPTADAS - MIGRACIÓN
-- ============================================

-- ============================================
-- 4.1 USUARIOS - Datos personales sensibles
-- ============================================

-- Crear nuevas columnas encriptadas
ALTER TABLE "USUARIOS"
  ADD COLUMN IF NOT EXISTS nombre_enc bytea,
  ADD COLUMN IF NOT EXISTS apellido_enc bytea,
  ADD COLUMN IF NOT EXISTS correo_enc bytea;

-- Migrar datos existentes a columnas encriptadas
UPDATE "USUARIOS"
SET
  nombre_enc = encrypt_text(nombre),
  apellido_enc = encrypt_text(apellido),
  correo_enc = encrypt_text(correo)
WHERE nombre_enc IS NULL;

-- Validar migración antes de eliminar columnas originales
-- DO $$
-- BEGIN
--   IF EXISTS (SELECT 1 FROM "USUARIOS" WHERE nombre_enc IS NULL) THEN
--     RAISE EXCEPTION 'Migración de usuarios incompleta';
--   END IF;
-- END $$;

-- Descomentar después de validar migración:
-- ALTER TABLE "USUARIOS" DROP COLUMN nombre;
-- ALTER TABLE "USUARIOS" DROP COLUMN apellido;
-- ALTER TABLE "USUARIOS" DROP COLUMN correo;

-- Crear vista para acceso desencriptado (para autenticación y consultas necesarias)
CREATE OR REPLACE VIEW v_usuarios_desencriptados AS
SELECT
  id_usuario,
  decrypt_text(nombre_enc) as nombre,
  decrypt_text(apellido_enc) as apellido,
  decrypt_text(correo_enc) as correo,
  password_hash,
  id_carrera,
  semestre,
  fecha_registro,
  ultimo_acceso,
  estado
FROM "USUARIOS";

-- ============================================
-- 4.2 CALIFICACIONES - Comentarios sensibles
-- ============================================

ALTER TABLE "CALIFICACIONES"
  ADD COLUMN IF NOT EXISTS comentario_enc bytea;

UPDATE "CALIFICACIONES"
SET comentario_enc = encrypt_text(comentario)
WHERE comentario_enc IS NULL;

-- Descomentar después de validar migración:
-- ALTER TABLE "CALIFICACIONES" DROP COLUMN comentario;

CREATE OR REPLACE VIEW v_calificaciones_desencriptadas AS
SELECT
  id_calificacion,
  id_reserva,
  id_evaluador,
  id_evaluado,
  puntuacion,
  decrypt_text(comentario_enc) as comentario,
  created_at
FROM "CALIFICACIONES";

-- ============================================
-- 4.3 CANCELACIONES - Motivos sensibles
-- ============================================

ALTER TABLE "CANCELACIONES"
  ADD COLUMN IF NOT EXISTS motivo_enc bytea;

UPDATE "CANCELACIONES"
SET motivo_enc = encrypt_text(motivo)
WHERE motivo_enc IS NULL;

-- Descomentar después de validar migración:
-- ALTER TABLE "CANCELACIONES" DROP COLUMN motivo;

CREATE OR REPLACE VIEW v_cancelaciones_desencriptadas AS
SELECT
  id_cancelacion,
  id_reserva,
  id_usuario,
  decrypt_text(motivo_enc) as motivo,
  horas_anticipacion,
  fecha_cancelacion
FROM "CANCELACIONES";

-- ============================================
-- 4.4 NOTIFICACIONES - Mensajes sensibles
-- ============================================

ALTER TABLE "NOTIFICACIONES"
  ADD COLUMN IF NOT EXISTS mensaje_enc bytea;

UPDATE "NOTIFICACIONES"
SET mensaje_enc = encrypt_text(mensaje)
WHERE mensaje_enc IS NULL;

-- Descomentar después de validar migración:
-- ALTER TABLE "NOTIFICACIONES" DROP COLUMN mensaje;

CREATE OR REPLACE VIEW v_notificaciones_desencriptadas AS
SELECT
  id_notificacion,
  id_usuario,
  tipo,
  titulo,
  decrypt_text(mensaje_enc) as mensaje,
  leida,
  created_at
FROM "NOTIFICACIONES";

-- ============================================
-- 4.5 AUDITORIA - Datos sensibles en JSONB
-- ============================================

-- Para JSONB, encriptamos el campo completo como texto
ALTER TABLE "AUDITORIA"
  ADD COLUMN IF NOT EXISTS datos_anteriores_enc bytea,
  ADD COLUMN IF NOT EXISTS datos_nuevos_enc bytea;

UPDATE "AUDITORIA"
SET
  datos_anteriores_enc = encrypt_text(datos_anteriores::text),
  datos_nuevos_enc = encrypt_text(datos_nuevos::text)
WHERE datos_anteriores_enc IS NULL;

-- Descomentar después de validar migración:
-- ALTER TABLE "AUDITORIA" DROP COLUMN datos_anteriores;
-- ALTER TABLE "AUDITORIA" DROP COLUMN datos_nuevos;

CREATE OR REPLACE VIEW v_auditoria_desencriptada AS
SELECT
  id_auditoria,
  id_usuario,
  accion,
  entidad,
  entidad_id,
  decrypt_text(datos_anteriores_enc)::jsonb as datos_anteriores,
  decrypt_text(datos_nuevos_enc)::jsonb as datos_nuevos,
  ip,
  created_at
FROM "AUDITORIA";

-- ============================================
-- 5. DISPARADORES (TRIGGERS) PARA ENCRIPTACIÓN AUTOMÁTICA
-- ============================================

-- Función de trigger para encriptar datos de usuarios
CREATE OR REPLACE FUNCTION trf_encrypt_usuario()
RETURNS trigger AS $$
BEGIN
  IF NEW.nombre_enc IS NULL AND NEW.nombre IS NOT NULL THEN
    NEW.nombre_enc = encrypt_text(NEW.nombre);
  END IF;
  IF NEW.apellido_enc IS NULL AND NEW.apellido IS NOT NULL THEN
    NEW.apellido_enc = encrypt_text(NEW.apellido);
  END IF;
  IF NEW.correo_enc IS NULL AND NEW.correo IS NOT NULL THEN
    NEW.correo_enc = encrypt_text(NEW.correo);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger para USUARIOS
DROP TRIGGER IF EXISTS trg_encrypt_usuario ON "USUARIOS";
CREATE TRIGGER trg_encrypt_usuario
  BEFORE INSERT OR UPDATE ON "USUARIOS"
  FOR EACH ROW
  EXECUTE FUNCTION trf_encrypt_usuario();

-- Función de trigger para encriptar comentarios
CREATE OR REPLACE FUNCTION trf_encrypt_calificacion()
RETURNS trigger AS $$
BEGIN
  IF NEW.comentario_enc IS NULL AND NEW.comentario IS NOT NULL THEN
    NEW.comentario_enc = encrypt_text(NEW.comentario);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_encrypt_calificacion ON "CALIFICACIONES";
CREATE TRIGGER trg_encrypt_calificacion
  BEFORE INSERT OR UPDATE ON "CALIFICACIONES"
  FOR EACH ROW
  EXECUTE FUNCTION trf_encrypt_calificacion();

-- Función de trigger para encriptar motivos
CREATE OR REPLACE FUNCTION trf_encrypt_cancelacion()
RETURNS trigger AS $$
BEGIN
  IF NEW.motivo_enc IS NULL AND NEW.motivo IS NOT NULL THEN
    NEW.motivo_enc = encrypt_text(NEW.motivo);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_encrypt_cancelacion ON "CANCELACIONES";
CREATE TRIGGER trg_encrypt_cancelacion
  BEFORE INSERT OR UPDATE ON "CANCELACIONES"
  FOR EACH ROW
  EXECUTE FUNCTION trf_encrypt_cancelacion();

-- Función de trigger para encriptar mensajes
CREATE OR REPLACE FUNCTION trf_encrypt_notificacion()
RETURNS trigger AS $$
BEGIN
  IF NEW.mensaje_enc IS NULL AND NEW.mensaje IS NOT NULL THEN
    NEW.mensaje_enc = encrypt_text(NEW.mensaje);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_encrypt_notificacion ON "NOTIFICACIONES";
CREATE TRIGGER trg_encrypt_notificacion
  BEFORE INSERT OR UPDATE ON "NOTIFICACIONES"
  FOR EACH ROW
  EXECUTE FUNCTION trf_encrypt_notificacion();

-- Función de trigger para encriptar auditoría
CREATE OR REPLACE FUNCTION trf_encrypt_auditoria()
RETURNS trigger AS $$
BEGIN
  IF NEW.datos_anteriores_enc IS NULL AND NEW.datos_anteriores IS NOT NULL THEN
    NEW.datos_anteriores_enc = encrypt_text(NEW.datos_anteriores::text);
  END IF;
  IF NEW.datos_nuevos_enc IS NULL AND NEW.datos_nuevos IS NOT NULL THEN
    NEW.datos_nuevos_enc = encrypt_text(NEW.datos_nuevos::text);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_encrypt_auditoria ON "AUDITORIA";
CREATE TRIGGER trg_encrypt_auditoria
  BEFORE INSERT OR UPDATE ON "AUDITORIA"
  FOR EACH ROW
  EXECUTE FUNCTION trf_encrypt_auditoria();

-- ============================================
-- 6. FUNCIONES DE BÚSQUEDA EN DATOS ENCRIPTADOS
-- ============================================

-- Búsqueda por correo (para autenticación)
CREATE OR REPLACE FUNCTION buscar_usuario_por_correo(p_correo text)
RETURNS TABLE (
  id_usuario uuid,
  nombre text,
  apellido text,
  correo text,
  password_hash text
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    u.id_usuario,
    decrypt_text(u.nombre_enc) as nombre,
    decrypt_text(u.apellido_enc) as apellido,
    decrypt_text(u.correo_enc) as correo,
    u.password_hash
  FROM "USUARIOS" u
  WHERE decrypt_text(u.correo_enc) = p_correo;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- 7. COMENTARIOS Y DOCUMENTACIÓN
-- ============================================

COMMENT ON FUNCTION get_encryption_key() IS 'Obtiene la clave de encriptación maestra desde configuración segura';
COMMENT ON FUNCTION encrypt_text IS 'Encripta texto usando AES-256';
COMMENT ON FUNCTION decrypt_text IS 'Desencripta texto usando AES-256';
COMMENT ON FUNCTION buscar_usuario_por_correo IS 'Busca usuario por correo desencriptando datos (para autenticación)';

COMMENT ON COLUMN "USUARIOS".nombre_enc IS 'Columna encriptada del nombre (AES-256)';
COMMENT ON COLUMN "USUARIOS".apellido_enc IS 'Columna encriptada del apellido (AES-256)';
COMMENT ON COLUMN "USUARIOS".correo_enc IS 'Columna encriptada del correo (AES-256)';

COMMENT ON COLUMN "CALIFICACIONES".comentario_enc IS 'Columna encriptada del comentario (AES-256)';
COMMENT ON COLUMN "CANCELACIONES".motivo_enc IS 'Columna encriptada del motivo (AES-256)';
COMMENT ON COLUMN "NOTIFICACIONES".mensaje_enc IS 'Columna encriptada del mensaje (AES-256)';
COMMENT ON COLUMN "AUDITORIA".datos_anteriores_enc IS 'Columna encriptada de datos anteriores (AES-256)';
COMMENT ON COLUMN "AUDITORIA".datos_nuevos_enc IS 'Columna encriptada de datos nuevos (AES-256)';

-- ============================================
-- 8. INSTRUCCIONES DE IMPLEMENTACIÓN
-- ============================================

-- PASO 1: Ejecutar este script en un entorno de desarrollo
-- PASO 2: Validar que los datos se encriptan correctamente
-- PASO 3: Probar las vistas desencriptadas
-- PASO 4: Descomentar los DROP COLUMN después de validación
-- PASO 5: Configurar variable de entorno app.encryption_key en producción
-- PASO 6: Rotar claves periódicamente según política de seguridad

-- Para rotar claves en el futuro:
-- 1. Crear nuevas columnas *_enc_v2
-- 2. Migrar datos con nueva clave
-- 3. Actualizar triggers para usar nuevas columnas
-- 4. Validar y eliminar columnas anteriores
