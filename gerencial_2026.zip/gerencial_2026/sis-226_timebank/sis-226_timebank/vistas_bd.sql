-- ============================================
-- VISTAS DE BASE DE DATOS - Sistema de Intercambio de Habilidades
-- Base de Datos v0.31
-- ============================================
-- Este archivo contiene vistas útiles para consultas frecuentes
-- Las vistas simplifican joins complejos y encapsulan lógica de negocio
-- ============================================

-- ============================================
-- 1. VISTAS DE USUARIOS
-- ============================================

-- Vista completa de usuarios con carrera y facultad
CREATE OR REPLACE VIEW v_usuarios_completo AS
SELECT
  u.id_usuario,
  u.nombre,
  u.apellido,
  u.correo,
  u.password_hash,
  u.id_carrera,
  c.nombre as nombre_carrera,
  c.facultad,
  u.semestre,
  u.fecha_registro,
  u.ultimo_acceso,
  u.estado
FROM "USUARIOS" u
LEFT JOIN "CARRERAS" c ON u.id_carrera = c.id_carrera;

-- Vista de usuarios con roles
CREATE OR REPLACE VIEW v_usuarios_roles AS
SELECT
  u.id_usuario,
  u.nombre,
  u.apellido,
  u.correo,
  u.estado,
  r.nombre as rol
FROM "USUARIOS" u
JOIN "USUARIO_ROLES" ur ON u.id_usuario = ur.id_usuario
JOIN "ROLES" r ON ur.id_rol = r.id_rol;

-- Vista de usuarios activos
CREATE OR REPLACE VIEW v_usuarios_activos AS
SELECT
  u.id_usuario,
  u.nombre,
  u.apellido,
  u.correo,
  c.nombre as carrera,
  c.facultad,
  u.semestre,
  u.fecha_registro,
  u.ultimo_acceso
FROM "USUARIOS" u
LEFT JOIN "CARRERAS" c ON u.id_carrera = c.id_carrera
WHERE u.estado = 'activo';

-- Vista de usuarios por facultad
CREATE OR REPLACE VIEW v_usuarios_por_facultad AS
SELECT
  c.facultad,
  c.nombre as carrera,
  COUNT(*) as total_usuarios,
  COUNT(*) FILTER (WHERE u.estado = 'activo') as usuarios_activos
FROM "CARRERAS" c
LEFT JOIN "USUARIOS" u ON c.id_carrera = u.id_carrera
GROUP BY c.facultad, c.nombre
ORDER BY c.facultad, c.nombre;

-- ============================================
-- 2. VISTAS DE HABILIDADES
-- ============================================

-- Vista de habilidades con categoría
CREATE OR REPLACE VIEW v_habilidades_categoria AS
SELECT
  h.id_habilidad,
  h.nombre as nombre_habilidad,
  cat.nombre as categoria,
  h.estado
FROM "HABILIDADES" h
JOIN "CATEGORIAS" cat ON h.id_categoria = cat.id_categoria;

-- Vista de habilidades de usuarios
CREATE OR REPLACE VIEW v_usuario_habilidades_detalle AS
SELECT
  u.id_usuario,
  u.nombre,
  u.apellido,
  h.id_habilidad,
  h.nombre as nombre_habilidad,
  cat.nombre as categoria,
  uh.nivel,
  h.estado as estado_habilidad
FROM "USUARIOS" u
JOIN "USUARIO_HABILIDADES" uh ON u.id_usuario = uh.id_usuario
JOIN "HABILIDADES" h ON uh.id_habilidad = h.id_habilidad
JOIN "CATEGORIAS" cat ON h.id_categoria = cat.id_categoria
WHERE h.estado = 'activo';

-- Vista de usuarios que ofrecen una habilidad específica
CREATE OR REPLACE VIEW v_ofertantes_por_habilidad AS
SELECT
  h.id_habilidad,
  h.nombre as nombre_habilidad,
  cat.nombre as categoria,
  COUNT(*) as total_ofertantes,
  COUNT(*) FILTER (WHERE u.estado = 'activo') as ofertantes_activos
FROM "HABILIDADES" h
JOIN "USUARIO_HABILIDADES" uh ON h.id_habilidad = uh.id_habilidad
JOIN "USUARIOS" u ON uh.id_usuario = u.id_usuario
JOIN "CATEGORIAS" cat ON h.id_categoria = cat.id_categoria
WHERE h.estado = 'activo'
GROUP BY h.id_habilidad, h.nombre, cat.nombre
ORDER BY total_ofertantes DESC;

-- Vista de habilidades más populares
CREATE OR REPLACE VIEW v_habilidades_populares AS
SELECT
  h.id_habilidad,
  h.nombre as nombre_habilidad,
  cat.nombre as categoria,
  COUNT(*) as total_ofertantes,
  COUNT(*) FILTER (WHERE u.estado = 'activo') as ofertantes_activos
FROM "HABILIDADES" h
JOIN "USUARIO_HABILIDADES" uh ON h.id_habilidad = uh.id_habilidad
JOIN "USUARIOS" u ON uh.id_usuario = u.id_usuario
JOIN "CATEGORIAS" cat ON h.id_categoria = cat.id_categoria
WHERE h.estado = 'activo'
GROUP BY h.id_habilidad, h.nombre, cat.nombre
HAVING COUNT(*) >= 1
ORDER BY total_ofertantes DESC
LIMIT 20;

-- ============================================
-- 3. VISTAS DE DISPONIBILIDAD
-- ============================================

-- Vista de disponibilidades con información de usuario
CREATE OR REPLACE VIEW v_disponibilidades_usuario AS
SELECT
  d.id_disponibilidad,
  u.id_usuario,
  u.nombre,
  u.apellido,
  d.fecha_inicio,
  d.fecha_fin,
  d.estado
FROM "DISPONIBILIDADES" d
JOIN "USUARIOS" u ON d.id_usuario = u.id_usuario
WHERE d.estado = 'activo'
  AND d.fecha_inicio > now()
ORDER BY d.fecha_inicio;

-- Vista de disponibilidades futuras por usuario
CREATE OR REPLACE VIEW v_disponibilidades_futuras AS
SELECT
  d.id_disponibilidad,
  u.id_usuario,
  u.nombre,
  u.apellido,
  d.fecha_inicio,
  d.fecha_fin,
  EXTRACT(EPOCH FROM (d.fecha_fin - d.fecha_inicio))/3600 as horas_disponibles,
  d.estado
FROM "DISPONIBILIDADES" d
JOIN "USUARIOS" u ON d.id_usuario = u.id_usuario
WHERE d.fecha_inicio > now()
  AND d.estado = 'activo'
ORDER BY d.fecha_inicio;

-- ============================================
-- 4. VISTAS DE SOLICITUDES
-- ============================================

-- Vista de solicitudes con nombres de usuarios y habilidad
CREATE OR REPLACE VIEW v_solicitudes_detalle AS
SELECT
  s.id_solicitud,
  s.id_solicitante,
  us.nombre as nombre_solicitante,
  us.apellido as apellido_solicitante,
  s.id_ofertante,
  uo.nombre as nombre_ofertante,
  uo.apellido as apellido_ofertante,
  s.id_habilidad,
  h.nombre as nombre_habilidad,
  cat.nombre as categoria,
  s.fecha_inicio_propuesta,
  s.fecha_fin_propuesta,
  s.creditos_requeridos,
  s.estado,
  s.created_at,
  s.respondida_at
FROM "SOLICITUDES_INTERCAMBIO" s
JOIN "USUARIOS" us ON s.id_solicitante = us.id_usuario
JOIN "USUARIOS" uo ON s.id_ofertante = uo.id_usuario
JOIN "HABILIDADES" h ON s.id_habilidad = h.id_habilidad
JOIN "CATEGORIAS" cat ON h.id_categoria = cat.id_categoria;

-- Vista de solicitudes pendientes por usuario
CREATE OR REPLACE VIEW v_solicitudes_pendientes AS
SELECT
  s.id_solicitud,
  s.id_solicitante,
  us.nombre as nombre_solicitante,
  s.id_ofertante,
  uo.nombre as nombre_ofertante,
  h.nombre as nombre_habilidad,
  s.fecha_inicio_propuesta,
  s.fecha_fin_propuesta,
  s.creditos_requeridos,
  s.created_at
FROM "SOLICITUDES_INTERCAMBIO" s
JOIN "USUARIOS" us ON s.id_solicitante = us.id_usuario
JOIN "USUARIOS" uo ON s.id_ofertante = uo.id_usuario
JOIN "HABILIDADES" h ON s.id_habilidad = h.id_habilidad
WHERE s.estado = 'solicitada'
ORDER BY s.created_at DESC;

-- Vista de solicitudes recibidas por usuario
CREATE OR REPLACE VIEW v_solicitudes_recibidas AS
SELECT
  s.id_solicitud,
  s.id_solicitante,
  us.nombre as nombre_solicitante,
  us.apellido as apellido_solicitante,
  s.id_ofertante,
  h.nombre as nombre_habilidad,
  s.fecha_inicio_propuesta,
  s.fecha_fin_propuesta,
  s.creditos_requeridos,
  s.estado,
  s.created_at
FROM "SOLICITUDES_INTERCAMBIO" s
JOIN "USUARIOS" us ON s.id_solicitante = us.id_usuario
JOIN "USUARIOS" uo ON s.id_ofertante = uo.id_usuario
JOIN "HABILIDADES" h ON s.id_habilidad = h.id_habilidad
WHERE s.id_ofertante = uo.id_usuario
  AND s.estado = 'solicitada'
ORDER BY s.created_at DESC;

-- Vista de solicitudes enviadas por usuario
CREATE OR REPLACE VIEW v_solicitudes_enviadas AS
SELECT
  s.id_solicitud,
  s.id_solicitante,
  s.id_ofertante,
  uo.nombre as nombre_ofertante,
  uo.apellido as apellido_ofertante,
  h.nombre as nombre_habilidad,
  s.fecha_inicio_propuesta,
  s.fecha_fin_propuesta,
  s.creditos_requeridos,
  s.estado,
  s.created_at,
  s.respondida_at
FROM "SOLICITUDES_INTERCAMBIO" s
JOIN "USUARIOS" us ON s.id_solicitante = us.id_usuario
JOIN "USUARIOS" uo ON s.id_ofertante = uo.id_usuario
JOIN "HABILIDADES" h ON s.id_habilidad = h.id_habilidad
WHERE s.id_solicitante = us.id_usuario
ORDER BY s.created_at DESC;

-- ============================================
-- 5. VISTAS DE RESERVAS
-- ============================================

-- Vista de reservas con información completa
CREATE OR REPLACE VIEW v_reservas_detalle AS
SELECT
  r.id_reserva,
  r.id_solicitud,
  r.id_solicitante,
  us.nombre as nombre_solicitante,
  us.apellido as apellido_solicitante,
  r.id_ofertante,
  uo.nombre as nombre_ofertante,
  uo.apellido as apellido_ofertante,
  r.id_habilidad,
  h.nombre as nombre_habilidad,
  cat.nombre as categoria,
  r.fecha_inicio,
  r.fecha_fin,
  r.creditos,
  r.modalidad,
  r.lugar,
  r.estado,
  r.created_at,
  r.completed_at,
  r.cancelled_at
FROM "RESERVAS" r
JOIN "USUARIOS" us ON r.id_solicitante = us.id_usuario
JOIN "USUARIOS" uo ON r.id_ofertante = uo.id_usuario
JOIN "HABILIDADES" h ON r.id_habilidad = h.id_habilidad
JOIN "CATEGORIAS" cat ON h.id_categoria = cat.id_categoria;

-- Vista de reservas activas
CREATE OR REPLACE VIEW v_reservas_activas AS
SELECT
  r.id_reserva,
  r.id_solicitante,
  us.nombre as nombre_solicitante,
  r.id_ofertante,
  uo.nombre as nombre_ofertante,
  h.nombre as nombre_habilidad,
  r.fecha_inicio,
  r.fecha_fin,
  r.modalidad,
  r.lugar,
  r.estado
FROM "RESERVAS" r
JOIN "USUARIOS" us ON r.id_solicitante = us.id_usuario
JOIN "USUARIOS" uo ON r.id_ofertante = uo.id_usuario
JOIN "HABILIDADES" h ON r.id_habilidad = h.id_habilidad
WHERE r.estado IN ('confirmada')
  AND r.fecha_inicio > now()
ORDER BY r.fecha_inicio;

-- Vista de reservas por usuario
CREATE OR REPLACE VIEW v_reservas_usuario AS
SELECT
  r.id_reserva,
  r.id_solicitante,
  us.nombre as nombre_solicitante,
  r.id_ofertante,
  uo.nombre as nombre_ofertante,
  h.nombre as nombre_habilidad,
  r.fecha_inicio,
  r.fecha_fin,
  r.creditos,
  r.modalidad,
  r.lugar,
  r.estado,
  r.created_at,
  r.completed_at,
  r.cancelled_at,
  CASE
    WHEN r.id_solicitante = u.id_usuario THEN 'solicitante'
    WHEN r.id_ofertante = u.id_usuario THEN 'ofertante'
  END as rol_usuario
FROM "RESERVAS" r
JOIN "USUARIOS" us ON r.id_solicitante = us.id_usuario
JOIN "USUARIOS" uo ON r.id_ofertante = uo.id_usuario
JOIN "HABILIDADES" h ON r.id_habilidad = h.id_habilidad
CROSS JOIN "USUARIOS" u
WHERE (r.id_solicitante = u.id_usuario OR r.id_ofertante = u.id_usuario);

-- Vista de reservas completadas
CREATE OR REPLACE VIEW v_reservas_completadas AS
SELECT
  r.id_reserva,
  r.id_solicitante,
  us.nombre as nombre_solicitante,
  r.id_ofertante,
  uo.nombre as nombre_ofertante,
  h.nombre as nombre_habilidad,
  r.fecha_inicio,
  r.fecha_fin,
  r.creditos,
  r.modalidad,
  r.completed_at
FROM "RESERVAS" r
JOIN "USUARIOS" us ON r.id_solicitante = us.id_usuario
JOIN "USUARIOS" uo ON r.id_ofertante = uo.id_usuario
JOIN "HABILIDADES" h ON r.id_habilidad = h.id_habilidad
WHERE r.estado = 'completada'
ORDER BY r.completed_at DESC;

-- ============================================
-- 6. VISTAS DE CRÉDITOS
-- ============================================

-- Vista de cuentas de crédito con información de usuario
CREATE OR REPLACE VIEW v_cuentas_credito_usuario AS
SELECT
  cc.id_cuenta,
  cc.id_usuario,
  u.nombre,
  u.apellido,
  u.correo,
  cc.saldo,
  cc.creditos_retenidos,
  cc.saldo - cc.creditos_retenidos as creditos_disponibles
FROM "CUENTAS_CREDITO" cc
JOIN "USUARIOS" u ON cc.id_usuario = u.id_usuario;

-- Vista de movimientos de crédito con detalles
CREATE OR REPLACE VIEW v_movimientos_credito_detalle AS
SELECT
  mc.id_movimiento,
  mc.id_cuenta,
  u.nombre,
  u.apellido,
  mc.id_reserva,
  mc.tipo,
  mc.cantidad,
  mc.saldo_anterior,
  mc.saldo_posterior,
  mc.retenidos_anterior,
  mc.retenidos_posterior,
  mc.descripcion,
  mc.created_at
FROM "MOVIMIENTOS_CREDITO" mc
JOIN "CUENTAS_CREDITO" cc ON mc.id_cuenta = cc.id_cuenta
JOIN "USUARIOS" u ON cc.id_usuario = u.id_usuario
ORDER BY mc.created_at DESC;

-- Vista de historial de transferencias
CREATE OR REPLACE VIEW v_transferencias_detalle AS
SELECT
  t.id_transferencia,
  t.id_reserva,
  t.id_emisor,
  ue.nombre as nombre_emisor,
  ue.apellido as apellido_emisor,
  t.id_receptor,
  ur.nombre as nombre_receptor,
  ur.apellido as apellido_receptor,
  t.cantidad,
  t.estado,
  t.fecha_transferencia,
  t.motivo
FROM "TRANSFERENCIAS_CREDITO" t
JOIN "USUARIOS" ue ON t.id_emisor = ue.id_usuario
JOIN "USUARIOS" ur ON t.id_receptor = ur.id_usuario
ORDER BY t.fecha_transferencia DESC;

-- Vista de ranking de créditos
CREATE OR REPLACE VIEW v_ranking_creditos AS
SELECT
  u.id_usuario,
  u.nombre,
  u.apellido,
  c.nombre as carrera,
  cc.saldo,
  cc.creditos_retenidos,
  cc.saldo - cc.creditos_retenidos as creditos_disponibles,
  RANK() OVER (ORDER BY cc.saldo DESC) as posicion_ranking
FROM "CUENTAS_CREDITO" cc
JOIN "USUARIOS" u ON cc.id_usuario = u.id_usuario
LEFT JOIN "CARRERAS" c ON u.id_carrera = c.id_carrera
WHERE u.estado = 'activo'
ORDER BY cc.saldo DESC;

-- ============================================
-- 7. VISTAS DE CALIFICACIONES
-- ============================================

-- Vista de calificaciones con nombres de usuarios
CREATE OR REPLACE VIEW v_calificaciones_detalle AS
SELECT
  c.id_calificacion,
  c.id_reserva,
  c.id_evaluador,
  ue.nombre as nombre_evaluador,
  ue.apellido as apellido_evaluador,
  c.id_evaluado,
  uo.nombre as nombre_evaluado,
  uo.apellido as apellido_evaluado,
  c.puntuacion,
  c.comentario,
  c.created_at
FROM "CALIFICACIONES" c
JOIN "USUARIOS" ue ON c.id_evaluador = ue.id_usuario
JOIN "USUARIOS" uo ON c.id_evaluado = uo.id_usuario;

-- Vista de reputación de usuarios
CREATE OR REPLACE VIEW v_reputacion_usuarios AS
SELECT
  u.id_usuario,
  u.nombre,
  u.apellido,
  AVG(c.puntuacion) as promedio_puntuacion,
  COUNT(*) FILTER (WHERE c.id_evaluado = u.id_usuario) as total_calificaciones_recibidas,
  COUNT(*) FILTER (WHERE c.id_evaluador = u.id_usuario) as total_calificaciones_dadas,
  COUNT(c.id_calificacion) as total_interacciones
FROM "USUARIOS" u
LEFT JOIN "CALIFICACIONES" c ON u.id_usuario = c.id_evaluado OR u.id_usuario = c.id_evaluador
WHERE u.estado = 'activo'
GROUP BY u.id_usuario, u.nombre, u.apellido
ORDER BY promedio_puntuacion DESC NULLS LAST;

-- Vista de calificaciones recibidas por usuario
CREATE OR REPLACE VIEW v_calificaciones_recibidas AS
SELECT
  c.id_calificacion,
  c.id_reserva,
  c.id_evaluador,
  ue.nombre as nombre_evaluador,
  ue.apellido as apellido_evaluador,
  c.id_evaluado,
  uo.nombre as nombre_evaluado,
  uo.apellido as apellido_evaluado,
  c.puntuacion,
  c.comentario,
  c.created_at
FROM "CALIFICACIONES" c
JOIN "USUARIOS" ue ON c.id_evaluador = ue.id_usuario
JOIN "USUARIOS" uo ON c.id_evaluado = uo.id_usuario
WHERE c.id_evaluado = uo.id_usuario
ORDER BY c.created_at DESC;

-- ============================================
-- 8. VISTAS DE NOTIFICACIONES
-- ============================================

-- Vista de notificaciones con información de usuario
CREATE OR REPLACE VIEW v_notificaciones_usuario AS
SELECT
  n.id_notificacion,
  n.id_usuario,
  u.nombre,
  u.apellido,
  n.tipo,
  n.titulo,
  n.mensaje,
  n.leida,
  n.created_at
FROM "NOTIFICACIONES" n
JOIN "USUARIOS" u ON n.id_usuario = u.id_usuario
ORDER BY n.created_at DESC;

-- Vista de notificaciones no leídas
CREATE OR REPLACE VIEW v_notificaciones_no_leidas AS
SELECT
  n.id_notificacion,
  n.id_usuario,
  u.nombre,
  u.apellido,
  n.tipo,
  n.titulo,
  n.mensaje,
  n.created_at
FROM "NOTIFICACIONES" n
JOIN "USUARIOS" u ON n.id_usuario = u.id_usuario
WHERE n.leida = false
ORDER BY n.created_at DESC;

-- Vista de notificaciones por tipo
CREATE OR REPLACE VIEW v_notificaciones_por_tipo AS
SELECT
  n.tipo,
  COUNT(*) as total_notificaciones,
  COUNT(*) FILTER (WHERE n.leida = false) as no_leidas,
  COUNT(*) FILTER (WHERE n.leida = true) as leidas
FROM "NOTIFICACIONES" n
GROUP BY n.tipo
ORDER BY total_notificaciones DESC;

-- ============================================
-- 9. VISTAS DE AUDITORÍA
-- ============================================

-- Vista de auditoría con información de usuario
CREATE OR REPLACE VIEW v_auditoria_detalle AS
SELECT
  a.id_auditoria,
  a.id_usuario,
  u.nombre,
  u.apellido,
  a.accion,
  a.entidad,
  a.entidad_id,
  a.datos_anteriores,
  a.datos_nuevos,
  a.ip,
  a.created_at
FROM "AUDITORIA" a
LEFT JOIN "USUARIOS" u ON a.id_usuario = u.id_usuario
ORDER BY a.created_at DESC;

-- Vista de auditoría por acción
CREATE OR REPLACE VIEW v_auditoria_por_accion AS
SELECT
  a.accion,
  COUNT(*) as total_eventos,
  COUNT(*) FILTER (WHERE a.created_at > now() - INTERVAL '7 days') as eventos_ultima_semana,
  COUNT(*) FILTER (WHERE a.created_at > now() - INTERVAL '30 days') as eventos_ultimo_mes
FROM "AUDITORIA" a
GROUP BY a.accion
ORDER BY total_eventos DESC;

-- Vista de auditoría por usuario
CREATE OR REPLACE VIEW v_auditoria_por_usuario AS
SELECT
  a.id_usuario,
  u.nombre,
  u.apellido,
  COUNT(*) as total_acciones,
  MAX(a.created_at) as ultima_accion
FROM "AUDITORIA" a
JOIN "USUARIOS" u ON a.id_usuario = u.id_usuario
GROUP BY a.id_usuario, u.nombre, u.apellido
ORDER BY total_acciones DESC;

-- ============================================
-- 10. VISTAS DE DASHBOARD Y REPORTES
-- ============================================

-- Vista de estadísticas generales del sistema
CREATE OR REPLACE VIEW v_estadisticas_generales AS
SELECT
  (SELECT COUNT(*) FROM "USUARIOS" WHERE estado = 'activo') as total_usuarios_activos,
  (SELECT COUNT(*) FROM "HABILIDADES" WHERE estado = 'activo') as total_habilidades_activas,
  (SELECT COUNT(*) FROM "SOLICITUDES_INTERCAMBIO" WHERE estado = 'solicitada') as solicitudes_pendientes,
  (SELECT COUNT(*) FROM "RESERVAS" WHERE estado = 'confirmada') as reservas_activas,
  (SELECT COUNT(*) FROM "RESERVAS" WHERE estado = 'completada') as reservas_completadas,
  (SELECT COUNT(*) FROM "RESERVAS" WHERE created_at > now() - INTERVAL '7 days') as reservas_ultima_semana,
  (SELECT SUM(saldo) FROM "CUENTAS_CREDITO") as total_creditos_en_sistema;

-- Vista de actividad por mes
CREATE OR REPLACE VIEW v_actividad_mensual AS
SELECT
  DATE_TRUNC('month', created_at) as mes,
  COUNT(*) FILTER (WHERE entidad = 'SOLICITUDES_INTERCAMBIO') as nuevas_solicitudes,
  COUNT(*) FILTER (WHERE entidad = 'RESERVAS') as nuevas_reservas,
  COUNT(*) FILTER (WHERE entidad = 'USUARIOS' AND accion = 'INSERT') as nuevos_usuarios
FROM "AUDITORIA"
WHERE created_at > now() - INTERVAL '12 months'
GROUP BY DATE_TRUNC('month', created_at)
ORDER BY mes DESC;

-- Vista de habilidades más solicitadas
CREATE OR REPLACE VIEW v_habilidades_mas_solicitadas AS
SELECT
  h.id_habilidad,
  h.nombre as nombre_habilidad,
  cat.nombre as categoria,
  COUNT(DISTINCT s.id_solicitud) as total_solicitudes,
  COUNT(DISTINCT s.id_solicitud) FILTER (WHERE s.estado = 'aceptada') as solicitudes_aceptadas
FROM "HABILIDADES" h
LEFT JOIN "SOLICITUDES_INTERCAMBIO" s ON h.id_habilidad = s.id_habilidad
JOIN "CATEGORIAS" cat ON h.id_categoria = cat.id_categoria
GROUP BY h.id_habilidad, h.nombre, cat.nombre
HAVING COUNT(DISTINCT s.id_solicitud) > 0
ORDER BY total_solicitudes DESC;

-- Vista de usuarios más activos
CREATE OR REPLACE VIEW v_usuarios_mas_activos AS
SELECT
  u.id_usuario,
  u.nombre,
  u.apellido,
  c.nombre as carrera,
  COUNT(DISTINCT r.id_reserva) as total_reservas,
  COUNT(DISTINCT r.id_reserva) FILTER (WHERE r.id_solicitante = u.id_usuario) as como_solicitante,
  COUNT(DISTINCT r.id_reserva) FILTER (WHERE r.id_ofertante = u.id_usuario) as como_ofertante
FROM "USUARIOS" u
LEFT JOIN "RESERVAS" r ON u.id_usuario = r.id_solicitante OR u.id_usuario = r.id_ofertante
LEFT JOIN "CARRERAS" c ON u.id_carrera = c.id_carrera
WHERE u.estado = 'activo'
GROUP BY u.id_usuario, u.nombre, u.apellido, c.nombre
HAVING COUNT(DISTINCT r.id_reserva) > 0
ORDER BY total_reservas DESC;

-- Vista de reservas por categoría
CREATE OR REPLACE VIEW v_reservas_por_categoria AS
SELECT
  cat.nombre as categoria,
  COUNT(DISTINCT r.id_reserva) as total_reservas,
  COUNT(DISTINCT r.id_reserva) FILTER (WHERE r.estado = 'completada') as reservas_completadas,
  ROUND(
    100.0 * COUNT(DISTINCT r.id_reserva) FILTER (WHERE r.estado = 'completada') /
    NULLIF(COUNT(DISTINCT r.id_reserva), 0),
    2
  ) as tasa_completacion
FROM "CATEGORIAS" cat
LEFT JOIN "HABILIDADES" h ON cat.id_categoria = h.id_categoria
LEFT JOIN "RESERVAS" r ON h.id_habilidad = r.id_habilidad
GROUP BY cat.nombre
ORDER BY total_reservas DESC;

-- ============================================
-- 11. COMENTARIOS DE DOCUMENTACIÓN
-- ============================================

COMMENT ON VIEW v_usuarios_completo IS 'Vista completa de usuarios con información de carrera y facultad';
COMMENT ON VIEW v_usuarios_roles IS 'Vista de usuarios con sus roles asignados';
COMMENT ON VIEW v_usuarios_activos IS 'Vista de usuarios con estado activo';
COMMENT ON VIEW v_usuarios_por_facultad IS 'Vista estadística de usuarios agrupados por facultad y carrera';

COMMENT ON VIEW v_habilidades_categoria IS 'Vista de habilidades con su categoría';
COMMENT ON VIEW v_usuario_habilidades_detalle IS 'Vista de habilidades de usuarios con nivel y categoría';
COMMENT ON VIEW v_ofertantes_por_habilidad IS 'Vista de cantidad de ofertantes por habilidad';
COMMENT ON VIEW v_habilidades_populares IS 'Vista de las 20 habilidades más populares';

COMMENT ON VIEW v_disponibilidades_usuario IS 'Vista de disponibilidades con información de usuario';
COMMENT ON VIEW v_disponibilidades_futuras IS 'Vista de disponibilidades futuras con cálculo de horas';

COMMENT ON VIEW v_solicitudes_detalle IS 'Vista completa de solicitudes con nombres y habilidad';
COMMENT ON VIEW v_solicitudes_pendientes IS 'Vista de solicitudes en estado solicitada';
COMMENT ON VIEW v_solicitudes_recibidas IS 'Vista de solicitudes recibidas por un usuario';
COMMENT ON VIEW v_solicitudes_enviadas IS 'Vista de solicitudes enviadas por un usuario';

COMMENT ON VIEW v_reservas_detalle IS 'Vista completa de reservas con información de participantes';
COMMENT ON VIEW v_reservas_activas IS 'Vista de reservas confirmadas y futuras';
COMMENT ON VIEW v_reservas_usuario IS 'Vista de reservas donde participa un usuario (como solicitante u ofertante)';
COMMENT ON VIEW v_reservas_completadas IS 'Vista de reservas completadas ordenadas por fecha';

COMMENT ON VIEW v_cuentas_credito_usuario IS 'Vista de cuentas de crédito con información de usuario y cálculo de disponibles';
COMMENT ON VIEW v_movimientos_credito_detalle IS 'Vista de movimientos de crédito con detalles de usuario';
COMMENT ON VIEW v_transferencias_detalle IS 'Vista de transferencias con nombres de emisor y receptor';
COMMENT ON VIEW v_ranking_creditos IS 'Vista de ranking de usuarios por saldo de créditos';

COMMENT ON VIEW v_calificaciones_detalle IS 'Vista de calificaciones con nombres de evaluador y evaluado';
COMMENT ON VIEW v_reputacion_usuarios IS 'Vista de reputación de usuarios con promedio y totales';
COMMENT ON VIEW v_calificaciones_recibidas IS 'Vista de calificaciones recibidas por un usuario';

COMMENT ON VIEW v_notificaciones_usuario IS 'Vista de notificaciones con información de usuario';
COMMENT ON VIEW v_notificaciones_no_leidas IS 'Vista de notificaciones no leídas';
COMMENT ON VIEW v_notificaciones_por_tipo IS 'Vista estadística de notificaciones por tipo';

COMMENT ON VIEW v_auditoria_detalle IS 'Vista de auditoría con información de usuario';
COMMENT ON VIEW v_auditoria_por_accion IS 'Vista estadística de auditoría por tipo de acción';
COMMENT ON VIEW v_auditoria_por_usuario IS 'Vista de auditoría agrupada por usuario';

COMMENT ON VIEW v_estadisticas_generales IS 'Vista de estadísticas generales del sistema';
COMMENT ON VIEW v_actividad_mensual IS 'Vista de actividad mensual de los últimos 12 meses';
COMMENT ON VIEW v_habilidades_mas_solicitadas IS 'Vista de habilidades más solicitadas con tasa de aceptación';
COMMENT ON VIEW v_usuarios_mas_activos IS 'Vista de usuarios más activos en intercambios';
COMMENT ON VIEW v_reservas_por_categoria IS 'Vista de reservas por categoría con tasa de completación';

-- ============================================
-- 12. NOTAS DE USO
-- ============================================

-- Las vistas se pueden usar directamente en consultas SQL:
-- SELECT * FROM v_usuarios_activos;
-- SELECT * FROM v_solicitudes_pendientes WHERE id_ofertante = 'uuid-aqui';
-- SELECT * FROM v_ranking_creditos LIMIT 10;

-- Las vistas también pueden usarse como base para reportes y dashboards
-- Las vistas que incluyen joins con USUARIOS en CROSS JOIN (como v_reservas_usuario)
-- requieren filtrar por un usuario específico para obtener resultados óptimos
