-- ============================================
-- RECOMENDACIONES ADICIONALES - Base de Datos v0.31
-- Sistema de Intercambio de Habilidades
-- ============================================
-- Este archivo contiene mejoras recomendadas para:
-- - Índices de rendimiento
-- - Constraints de integridad
-- - Triggers de validación
-- - Procedimientos almacenados
-- - Funciones de utilidad
-- ============================================

-- ============================================
-- 1. ÍNDICES DE RENDIMIENTO
-- ============================================

-- Índices para búsqueda por estado en tablas principales
CREATE INDEX IF NOT EXISTS idx_usuarios_estado ON "USUARIOS"(estado);
CREATE INDEX IF NOT EXISTS idx_usuarios_carrera ON "USUARIOS"(id_carrera);
CREATE INDEX IF NOT EXISTS idx_usuarios_registro ON "USUARIOS"(fecha_registro DESC);

CREATE INDEX IF NOT EXISTS idx_habilidades_categoria ON "HABILIDADES"(id_categoria);
CREATE INDEX IF NOT EXISTS idx_habilidades_estado ON "HABILIDADES"(estado);

CREATE INDEX IF NOT EXISTS idx_disponibilidades_usuario ON "DISPONIBILIDADES"(id_usuario);
CREATE INDEX IF NOT EXISTS idx_disponibilidades_fecha ON "DISPONIBILIDADES"(fecha_inicio, fecha_fin);
CREATE INDEX IF NOT EXISTS idx_disponibilidades_estado ON "DISPONIBILIDADES"(estado);

CREATE INDEX IF NOT EXISTS idx_solicitudes_solicitante ON "SOLICITUDES_INTERCAMBIO"(id_solicitante);
CREATE INDEX IF NOT EXISTS idx_solicitudes_ofertante ON "SOLICITUDES_INTERCAMBIO"(id_ofertante);
CREATE INDEX IF NOT EXISTS idx_solicitudes_habilidad ON "SOLICITUDES_INTERCAMBIO"(id_habilidad);
CREATE INDEX IF NOT EXISTS idx_solicitudes_estado ON "SOLICITUDES_INTERCAMBIO"(estado);
CREATE INDEX IF NOT EXISTS idx_solicitudes_fecha ON "SOLICITUDES_INTERCAMBIO"(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_reservas_solicitante ON "RESERVAS"(id_solicitante);
CREATE INDEX IF NOT EXISTS idx_reservas_ofertante ON "RESERVAS"(id_ofertante);
CREATE INDEX IF NOT EXISTS idx_reservas_estado ON "RESERVAS"(estado);
CREATE INDEX IF NOT EXISTS idx_reservas_fecha ON "RESERVAS"(fecha_inicio, fecha_fin);

CREATE INDEX IF NOT EXISTS idx_cuentas_usuario ON "CUENTAS_CREDITO"(id_usuario);
CREATE INDEX IF NOT EXISTS idx_movimientos_cuenta ON "MOVIMIENTOS_CREDITO"(id_cuenta);
CREATE INDEX IF NOT EXISTS idx_movimientos_fecha ON "MOVIMIENTOS_CREDITO"(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_calificaciones_evaluado ON "CALIFICACIONES"(id_evaluado);
CREATE INDEX IF NOT EXISTS idx_calificaciones_reserva ON "CALIFICACIONES"(id_reserva);

CREATE INDEX IF NOT EXISTS idx_notificaciones_usuario ON "NOTIFICACIONES"(id_usuario);
CREATE INDEX IF NOT EXISTS idx_notificaciones_leida ON "NOTIFICACIONES"(leida);
CREATE INDEX IF NOT EXISTS idx_notificaciones_fecha ON "NOTIFICACIONES"(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_auditoria_usuario ON "AUDITORIA"(id_usuario);
CREATE INDEX IF NOT EXISTS idx_auditoria_accion ON "AUDITORIA"(accion);
CREATE INDEX IF NOT EXISTS idx_auditoria_fecha ON "AUDITORIA"(created_at DESC);

-- Índices compuestos para consultas frecuentes
CREATE INDEX IF NOT EXISTS idx_solicitudes_solicitante_estado
  ON "SOLICITUDES_INTERCAMBIO"(id_solicitante, estado);
CREATE INDEX IF NOT EXISTS idx_solicitudes_ofertante_estado
  ON "SOLICITUDES_INTERCAMBIO"(id_ofertante, estado);

CREATE INDEX IF NOT EXISTS idx_reservas_usuario_estado
  ON "RESERVAS"(id_solicitante, estado);
CREATE INDEX IF NOT EXISTS idx_reservas_ofertante_estado
  ON "RESERVAS"(id_ofertante, estado);

-- Índice GIN para búsqueda en datos de auditoría (JSONB)
CREATE INDEX IF NOT EXISTS idx_auditoria_datos_anteriores
  ON "AUDITORIA" USING gin(datos_anteriores);
CREATE INDEX IF NOT EXISTS idx_auditoria_datos_nuevos
  ON "AUDITORIA" USING gin(datos_nuevos);

-- ============================================
-- 2. CONSTRAINTS ADICIONALES
-- ============================================

-- Constraint CHECK para saldos no negativos
ALTER TABLE "CUENTAS_CREDITO"
  ADD CONSTRAINT chk_saldo_no_negativo
  CHECK (saldo >= 0);

ALTER TABLE "CUENTAS_CREDITO"
  ADD CONSTRAINT chk_retenidos_validos
  CHECK (creditos_retenidos >= 0 AND creditos_retenidos <= saldo);

-- Constraint CHECK para puntuaciones (1-5)
ALTER TABLE "CALIFICACIONES"
  ADD CONSTRAINT chk_puntuacion_rango
  CHECK (puntuacion BETWEEN 1 AND 5);

-- Constraint CHECK para fechas (inicio < fin)
ALTER TABLE "DISPONIBILIDADES"
  ADD CONSTRAINT chk_fechas_disponibilidad
  CHECK (fecha_inicio < fecha_fin);

ALTER TABLE "SOLICITUDES_INTERCAMBIO"
  ADD CONSTRAINT chk_fechas_solicitud
  CHECK (fecha_inicio_propuesta < fecha_fin_propuesta);

ALTER TABLE "RESERVAS"
  ADD CONSTRAINT chk_fechas_reserva
  CHECK (fecha_inicio < fecha_fin);

-- Constraint CHECK para estados permitidos
ALTER TABLE "SOLICITUDES_INTERCAMBIO"
  ADD CONSTRAINT chk_estado_solicitud
  CHECK (estado IN ('solicitada', 'aceptada', 'rechazada', 'cancelada'));

ALTER TABLE "RESERVAS"
  ADD CONSTRAINT chk_estado_reserva
  CHECK (estado IN ('confirmada', 'completada', 'cancelada'));

ALTER TABLE "USUARIOS"
  ADD CONSTRAINT chk_estado_usuario
  CHECK (estado IN ('activo', 'inactivo', 'suspendido', 'eliminado'));

ALTER TABLE "HABILIDADES"
  ADD CONSTRAINT chk_estado_habilidad
  CHECK (estado IN ('activo', 'inactivo'));

ALTER TABLE "CARRERAS"
  ADD CONSTRAINT chk_estado_carrera
  CHECK (estado IN ('activo', 'inactivo'));

ALTER TABLE "CATEGORIAS"
  ADD CONSTRAINT chk_estado_categoria
  CHECK (estado IN ('activo', 'inactivo'));

ALTER TABLE "TRANSFERENCIAS_CREDITO"
  ADD CONSTRAINT chk_estado_transferencia
  CHECK (estado IN ('pendiente', 'completada', 'fallida'));

-- Constraint CHECK para semestre (rango típico universitario)
ALTER TABLE "USUARIOS"
  ADD CONSTRAINT chk_semestre_rango
  CHECK (semestre BETWEEN 1 AND 12);

-- Constraint CHECK para créditos requeridos positivos
ALTER TABLE "SOLICITUDES_INTERCAMBIO"
  ADD CONSTRAINT chk_creditos_positivos
  CHECK (creditos_requeridos > 0);

-- Constraint CHECK para modalidad de reserva
ALTER TABLE "RESERVAS"
  ADD CONSTRAINT chk_modalidad_reserva
  CHECK (modalidad IN ('presencial', 'virtual', 'hibrida'));

-- ============================================
-- 3. TRIGGERS DE VALIDACIÓN
-- ============================================

-- Trigger para actualizar ultimo_acceso en login
CREATE OR REPLACE FUNCTION trf_actualizar_ultimo_acceso()
RETURNS trigger AS $$
BEGIN
  NEW.ultimo_acceso = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para detectar cambio de estado y registrar en auditoría
CREATE OR REPLACE FUNCTION trf_auditar_cambio_estado()
RETURNS trigger AS $$
DECLARE
  v_datos_anteriores jsonb;
  v_datos_nuevos jsonb;
BEGIN
  IF TG_OP = 'UPDATE' AND OLD.estado IS DISTINCT FROM NEW.estado THEN
    v_datos_anteriores = to_jsonb(OLD);
    v_datos_nuevos = to_jsonb(NEW);

    INSERT INTO "AUDITORIA" (
      id_usuario,
      accion,
      entidad,
      entidad_id,
      datos_anteriores,
      datos_nuevos,
      ip
    ) VALUES (
      COALESCE(NEW.id_usuario, OLD.id_usuario),
      'UPDATE_ESTADO',
      TG_TABLE_NAME,
      COALESCE(NEW.id_solicitud, NEW.id_reserva, NEW.id_usuario, OLD.id_usuario),
      v_datos_anteriores,
      v_datos_nuevos,
      inet_client_addr()::text
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Aplicar trigger de auditoría de estado a tablas principales
DROP TRIGGER IF EXISTS trg_auditar_estado_solicitudes ON "SOLICITUDES_INTERCAMBIO";
CREATE TRIGGER trg_auditar_estado_solicitudes
  AFTER UPDATE OF estado ON "SOLICITUDES_INTERCAMBIO"
  FOR EACH ROW
  EXECUTE FUNCTION trf_auditar_cambio_estado();

DROP TRIGGER IF EXISTS trg_auditar_estado_reservas ON "RESERVAS";
CREATE TRIGGER trg_auditar_estado_reservas
  AFTER UPDATE OF estado ON "RESERVAS"
  FOR EACH ROW
  EXECUTE FUNCTION trf_auditar_cambio_estado();

-- Trigger para validar saldos antes de transferencia
CREATE OR REPLACE FUNCTION trf_validar_saldo_transferencia()
RETURNS trigger AS $$
DECLARE
  v_saldo_emisor int;
  v_cuenta_emisor uuid;
BEGIN
  IF TG_OP = 'INSERT' THEN
    -- Obtener cuenta del emisor
    SELECT id_cuenta INTO v_cuenta_emisor
    FROM "CUENTAS_CREDITO"
    WHERE id_usuario = NEW.id_emisor;

    -- Obtener saldo actual
    SELECT saldo INTO v_saldo_emisor
    FROM "CUENTAS_CREDITO"
    WHERE id_cuenta = v_cuenta_emisor;

    -- Validar saldo suficiente
    IF v_saldo_emisor < NEW.cantidad THEN
      RAISE EXCEPTION 'Saldo insuficiente: tiene % pero necesita %',
        v_saldo_emisor, NEW.cantidad;
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_validar_saldo ON "TRANSFERENCIAS_CREDITO";
CREATE TRIGGER trg_validar_saldo
  BEFORE INSERT ON "TRANSFERENCIAS_CREDITO"
  FOR EACH ROW
  EXECUTE FUNCTION trf_validar_saldo_transferencia();

-- ============================================
-- 4. PROCEDIMIENTOS ALMACENADOS
-- ============================================

-- Procedimiento para crear cuenta de crédito para nuevo usuario
CREATE OR REPLACE PROCEDURE crear_cuenta_usuario(p_id_usuario uuid)
LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO "CUENTAS_CREDITO" (id_cuenta, id_usuario, saldo, creditos_retenidos)
  VALUES (gen_random_uuid(), p_id_usuario, 0, 0);

  -- Bono inicial de 10 créditos para nuevos usuarios
  INSERT INTO "MOVIMIENTOS_CREDITO" (
    id_movimiento,
    id_cuenta,
    tipo,
    cantidad,
    saldo_anterior,
    saldo_posterior,
    retenidos_anterior,
    retenidos_posterior,
    descripcion
  )
  SELECT
    gen_random_uuid(),
    cc.id_cuenta,
    'bono_inicial',
    10,
    cc.saldo,
    cc.saldo + 10,
    cc.creditos_retenidos,
    cc.creditos_retenidos,
    'Bono de bienvenida para nuevo usuario'
  FROM "CUENTAS_CREDITO" cc
  WHERE cc.id_usuario = p_id_usuario;

  -- Actualizar saldo
  UPDATE "CUENTAS_CREDITO"
  SET saldo = saldo + 10
  WHERE id_usuario = p_id_usuario;
END;
$$;

-- Procedimiento para transferir créditos
CREATE OR REPLACE PROCEDURE transferir_creditos(
  p_id_emisor uuid,
  p_id_receptor uuid,
  p_cantidad int,
  p_id_reserva uuid,
  p_motivo varchar
)
LANGUAGE plpgsql AS $$
DECLARE
  v_cuenta_emisor uuid;
  v_cuenta_receptor uuid;
  v_saldo_emisor int;
  v_saldo_receptor int;
BEGIN
  -- Obtener cuentas
  SELECT id_cuenta, saldo INTO v_cuenta_emisor, v_saldo_emisor
  FROM "CUENTAS_CREDITO"
  WHERE id_usuario = p_id_emisor;

  SELECT id_cuenta, saldo INTO v_cuenta_receptor, v_saldo_receptor
  FROM "CUENTAS_CREDITO"
  WHERE id_usuario = p_id_receptor;

  -- Validar saldo
  IF v_saldo_emisor < p_cantidad THEN
    RAISE EXCEPTION 'Saldo insuficiente: tiene % pero necesita %',
      v_saldo_emisor, p_cantidad;
  END IF;

  -- Registrar transferencia
  INSERT INTO "TRANSFERENCIAS_CREDITO" (
    id_transferencia,
    id_reserva,
    id_emisor,
    id_receptor,
    cantidad,
    estado,
    motivo
  ) VALUES (
    gen_random_uuid(),
    p_id_reserva,
    p_id_emisor,
    p_id_receptor,
    p_cantidad,
    'completada',
    p_motivo
  );

  -- Movimiento de débito para emisor
  INSERT INTO "MOVIMIENTOS_CREDITO" (
    id_movimiento,
    id_cuenta,
    id_reserva,
    tipo,
    cantidad,
    saldo_anterior,
    saldo_posterior,
    retenidos_anterior,
    retenidos_posterior,
    descripcion
  ) VALUES (
    gen_random_uuid(),
    v_cuenta_emisor,
    p_id_reserva,
    'transferencia',
    -p_cantidad,
    v_saldo_emisor,
    v_saldo_emisor - p_cantidad,
    (SELECT creditos_retenidos FROM "CUENTAS_CREDITO" WHERE id_cuenta = v_cuenta_emisor),
    (SELECT creditos_retenidos FROM "CUENTAS_CREDITO" WHERE id_cuenta = v_cuenta_emisor),
    'Transferencia de créditos: ' || p_motivo
  );

  -- Movimiento de crédito para receptor
  INSERT INTO "MOVIMIENTOS_CREDITO" (
    id_movimiento,
    id_cuenta,
    id_reserva,
    tipo,
    cantidad,
    saldo_anterior,
    saldo_posterior,
    retenidos_anterior,
    retenidos_posterior,
    descripcion
  ) VALUES (
    gen_random_uuid(),
    v_cuenta_receptor,
    p_id_reserva,
    'transferencia',
    p_cantidad,
    v_saldo_receptor,
    v_saldo_receptor + p_cantidad,
    (SELECT creditos_retenidos FROM "CUENTAS_CREDITO" WHERE id_cuenta = v_cuenta_receptor),
    (SELECT creditos_retenidos FROM "CUENTAS_CREDITO" WHERE id_cuenta = v_cuenta_receptor),
    'Recepción de créditos: ' || p_motivo
  );

  -- Actualizar saldos
  UPDATE "CUENTAS_CREDITO"
  SET saldo = saldo - p_cantidad
  WHERE id_cuenta = v_cuenta_emisor;

  UPDATE "CUENTAS_CREDITO"
  SET saldo = saldo + p_cantidad
  WHERE id_cuenta = v_cuenta_receptor;
END;
$$;

-- Procedimiento para calcular reputación de usuario
CREATE OR REPLACE FUNCTION calcular_reputacion_usuario(p_id_usuario uuid)
RETURNS TABLE (
  promedio_puntuacion numeric,
  total_calificaciones int,
  calificaciones_recibidas int,
  calificaciones_dadas int
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    AVG(c.puntuacion) as promedio_puntuacion,
    COUNT(*) as total_calificaciones,
    COUNT(*) FILTER (WHERE c.id_evaluado = p_id_usuario) as calificaciones_recibidas,
    COUNT(*) FILTER (WHERE c.id_evaluador = p_id_usuario) as calificaciones_dadas
  FROM "CALIFICACIONES" c
  WHERE c.id_evaluado = p_id_usuario OR c.id_evaluador = p_id_usuario;
END;
$$ LANGUAGE plpgsql;

-- Procedimiento para notificar usuario
CREATE OR REPLACE PROCEDURE notificar_usuario(
  p_id_usuario uuid,
  p_tipo varchar,
  p_titulo varchar,
  p_mensaje text
)
LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO "NOTIFICACIONES" (
    id_notificacion,
    id_usuario,
    tipo,
    titulo,
    mensaje,
    leida
  ) VALUES (
    gen_random_uuid(),
    p_id_usuario,
    p_tipo,
    p_titulo,
    p_mensaje,
    false
  );
END;
$$;

-- Procedimiento para retener créditos (para reserva en proceso)
CREATE OR REPLACE PROCEDURE retener_creditos(
  p_id_usuario uuid,
  p_id_reserva uuid,
  p_cantidad int
)
LANGUAGE plpgsql AS $$
DECLARE
  v_cuenta uuid;
  v_saldo int;
  v_retenidos int;
BEGIN
  SELECT id_cuenta, saldo, creditos_retenidos
  INTO v_cuenta, v_saldo, v_retenidos
  FROM "CUENTAS_CREDITO"
  WHERE id_usuario = p_id_usuario;

  IF v_saldo - v_retenidos < p_cantidad THEN
    RAISE EXCEPTION 'Créditos disponibles insuficientes para retención';
  END IF;

  -- Registrar movimiento de retención
  INSERT INTO "MOVIMIENTOS_CREDITO" (
    id_movimiento,
    id_cuenta,
    id_reserva,
    tipo,
    cantidad,
    saldo_anterior,
    saldo_posterior,
    retenidos_anterior,
    retenidos_posterior,
    descripcion
  ) VALUES (
    gen_random_uuid(),
    v_cuenta,
    p_id_reserva,
    'retencion',
    0,
    v_saldo,
    v_saldo,
    v_retenidos,
    v_retenidos + p_cantidad,
    'Retención de créditos para reserva'
  );

  -- Actualizar retenidos
  UPDATE "CUENTAS_CREDITO"
  SET creditos_retenidos = creditos_retenidos + p_cantidad
  WHERE id_cuenta = v_cuenta;
END;
$$;

-- Procedimiento para liberar créditos retenidos
CREATE OR REPLACE PROCEDURE liberar_creditos_retenidos(
  p_id_usuario uuid,
  p_id_reserva uuid,
  p_cantidad int
)
LANGUAGE plpgsql AS $$
DECLARE
  v_cuenta uuid;
  v_retenidos int;
BEGIN
  SELECT id_cuenta, creditos_retenidos
  INTO v_cuenta, v_retenidos
  FROM "CUENTAS_CREDITO"
  WHERE id_usuario = p_id_usuario;

  IF v_retenidos < p_cantidad THEN
    RAISE EXCEPTION 'Créditos retenidos insuficientes para liberar';
  END IF;

  -- Registrar movimiento de liberación
  INSERT INTO "MOVIMIENTOS_CREDITO" (
    id_movimiento,
    id_cuenta,
    id_reserva,
    tipo,
    cantidad,
    saldo_anterior,
    saldo_posterior,
    retenidos_anterior,
    retenidos_posterior,
    descripcion
  ) VALUES (
    gen_random_uuid(),
    v_cuenta,
    p_id_reserva,
    'liberacion',
    0,
    (SELECT saldo FROM "CUENTAS_CREDITO" WHERE id_cuenta = v_cuenta),
    (SELECT saldo FROM "CUENTAS_CREDITO" WHERE id_cuenta = v_cuenta),
    v_retenidos,
    v_retenidos - p_cantidad,
    'Liberación de créditos retenidos'
  );

  -- Actualizar retenidos
  UPDATE "CUENTAS_CREDITO"
  SET creditos_retenidos = creditos_retenidos - p_cantidad
  WHERE id_cuenta = v_cuenta;
END;
$$;

-- ============================================
-- 5. FUNCIONES DE UTILIDAD
-- ============================================

-- Función para obtener habilidades disponibles de un usuario
CREATE OR REPLACE FUNCTION obtener_habilidades_usuario(p_id_usuario uuid)
RETURNS TABLE (
  id_habilidad uuid,
  nombre_habilidad varchar,
  categoria varchar,
  nivel varchar
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    h.id_habilidad,
    h.nombre as nombre_habilidad,
    c.nombre as categoria,
    uh.nivel
  FROM "USUARIO_HABILIDADES" uh
  JOIN "HABILIDADES" h ON uh.id_habilidad = h.id_habilidad
  JOIN "CATEGORIAS" c ON h.id_categoria = c.id_categoria
  WHERE uh.id_usuario = p_id_usuario
    AND h.estado = 'activo';
END;
$$ LANGUAGE plpgsql;

-- Función para obtener disponibilidad futura de un usuario
CREATE OR REPLACE FUNCTION obtener_disponibilidad_usuario(p_id_usuario uuid)
RETURNS TABLE (
  id_disponibilidad uuid,
  fecha_inicio timestamptz,
  fecha_fin timestamptz,
  estado varchar
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    d.id_disponibilidad,
    d.fecha_inicio,
    d.fecha_fin,
    d.estado
  FROM "DISPONIBILIDADES" d
  WHERE d.id_usuario = p_id_usuario
    AND d.fecha_inicio > now()
    AND d.estado = 'activo'
  ORDER BY d.fecha_inicio;
END;
$$ LANGUAGE plpgsql;

-- Función para verificar disponibilidad en rango de fechas
CREATE OR REPLACE FUNCTION verificar_disponibilidad(
  p_id_usuario uuid,
  p_fecha_inicio timestamptz,
  p_fecha_fin timestamptz
)
RETURNS boolean AS $$
DECLARE
  v_conflicto int;
BEGIN
  -- Verificar si hay conflicto con disponibilidades existentes
  SELECT COUNT(*) INTO v_conflicto
  FROM "DISPONIBILIDADES"
  WHERE id_usuario = p_id_usuario
    AND estado = 'activo'
    AND (
      (fecha_inicio <= p_fecha_inicio AND fecha_fin >= p_fecha_inicio) OR
      (fecha_inicio <= p_fecha_fin AND fecha_fin >= p_fecha_fin) OR
      (fecha_inicio >= p_fecha_inicio AND fecha_fin <= p_fecha_fin)
    );

  RETURN v_conflicto = 0;
END;
$$ LANGUAGE plpgsql;

-- Función para obtener saldo con créditos disponibles
CREATE OR REPLACE FUNCTION obtener_saldo_disponible(p_id_usuario uuid)
RETURNS TABLE (
  saldo_total int,
  creditos_retenidos int,
  creditos_disponibles int
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    cc.saldo as saldo_total,
    cc.creditos_retenidos,
    cc.saldo - cc.creditos_retenidos as creditos_disponibles
  FROM "CUENTAS_CREDITO" cc
  WHERE cc.id_usuario = p_id_usuario;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- 6. COMENTARIOS DE DOCUMENTACIÓN
-- ============================================

COMMENT ON PROCEDURE crear_cuenta_usuario IS 'Crea cuenta de crédito con bono inicial para nuevo usuario';
COMMENT ON PROCEDURE transferir_creditos IS 'Transfiere créditos entre usuarios con validación de saldo';
COMMENT ON PROCEDURE notificar_usuario IS 'Crea notificación para un usuario';
COMMENT ON PROCEDURE retener_creditos IS 'Retiene créditos para reserva en proceso';
COMMENT ON PROCEDURE liberar_creditos_retenidos IS 'Libera créditos retenidos tras completar/cancelar reserva';

COMMENT ON FUNCTION calcular_reputacion_usuario IS 'Calcula métricas de reputación de usuario';
COMMENT ON FUNCTION obtener_habilidades_usuario IS 'Obtiene habilidades activas de un usuario';
COMMENT ON FUNCTION obtener_disponibilidad_usuario IS 'Obtiene disponibilidades futuras de un usuario';
COMMENT ON FUNCTION verificar_disponibilidad IS 'Verifica si no hay conflicto en rango de fechas';
COMMENT ON FUNCTION obtener_saldo_disponible IS 'Obtiene saldo total, retenidos y disponibles de usuario';

-- ============================================
-- 7. ROLES Y PERMISOS RECOMENDADOS
-- ============================================

-- Crear roles de aplicación
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'app_readonly') THEN
    CREATE ROLE app_readonly;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'app_readwrite') THEN
    CREATE ROLE app_readwrite;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'app_admin') THEN
    CREATE ROLE app_admin;
  END IF;
END $$;

-- Permisos para app_readonly (lectura)
GRANT USAGE ON SCHEMA public TO app_readonly;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO app_readonly;
GRANT SELECT ON ALL SEQUENCES IN SCHEMA public TO app_readonly;

-- Permisos para app_readwrite (lectura/escritura)
GRANT USAGE ON SCHEMA public TO app_readwrite;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA public TO app_readwrite;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO app_readwrite;

-- Permisos para app_admin (administración completa)
GRANT ALL PRIVILEGES ON SCHEMA public TO app_admin;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO app_admin;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO app_admin;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO app_admin;

-- ============================================
-- 8. NOTAS DE IMPLEMENTACIÓN
-- ============================================

-- RECOMENDACIONES:
-- 1. Los índices mejoran rendimiento pero ocupan espacio - evaluar según volumen de datos
-- 2. Los constraints garantizan integridad pero pueden afectar rendimiento en alta concurrencia
-- 3. Los procedimientos encapsulan lógica de negocio en la base de datos
-- 4. Los triggers ejecutan automáticamente acciones de validación/auditoría
-- 5. Los roles y permisos implementan principio de mínimo privilegio

-- PASOS DE IMPLEMENTACIÓN:
-- 1. Ejecutar índices en horario de bajo tráfico
-- 2. Probar constraints con datos reales antes de producción
-- 3. Validar procedimientos con casos de prueba
-- 4. Monitorear impacto de triggers en rendimiento
-- 5. Configurar usuarios de aplicación con roles apropiados
